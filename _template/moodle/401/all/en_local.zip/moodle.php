<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://pg.al42.lms.int.lmsnetz.de
 *
 * @package    core
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['emailonlyallowed'] = 'This email is not one of those that are allowed.';
$string['newusernewpasswordtext'] = 'Hi {$a->firstname}, </br>
A new account OR a new temporary password has been created for you at \'{$a->sitename}\' </br>
Your current login information is now: </br>
username: {$a->username} </br>
password: {$a->newpassword} </br>
(you will have to change your password when you login for the first time)</br>
To start using \'{$a->sitename}\', login at {$a->link} In most mail programs, this should appear as a blue link which you can just click on. </br>
If that doesn\'t work, then cut and paste the address into the address line at the top of your web browser window.</br>
Cheers from the \'{$a->sitename}\' </br>
administrator, {$a->signoff}';
