<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://pg.al42.lms.int.lmsnetz.de
 *
 * @package    core
 * @subpackage admin
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['maintenancemodeisscheduled'] = 'Die Lernplattform wird in {$a->min} Minuten {$a->sec} Sekunden aktualisiert und wird für wenige Minuten nicht verfügbar sein. Bitte speichern Sie Ihre Arbeit und loggen Sie sich aus, falls möglich.';
$string['maintenancemodeisscheduledlong'] = 'Die Lernplattform wird in {$a->hour} Stunden {$a->min} Minuten {$a->sec} Sekunden aktualisiert und wird für wenige Minuten nicht verfügbar sein. Bitte speichern Sie Ihre Arbeit und loggen Sie sich aus, falls möglich.';
$string['sitemaintenance'] = 'Die Lernplattform wird aktualisiert und wird in Kürze wieder verfügbar sein.';
$string['sitemaintenancetitle'] = '{$a} wird aktualisiert';
