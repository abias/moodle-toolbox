<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://pg.al42.lms.int.lmsnetz.de
 *
 * @package    core
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['emailonlyallowed'] = 'Diese E-Mail-Adresse kann nicht verwendet werden.';
$string['newusernewpasswordtext'] = 'Guten Tag {$a->firstname}, </br>
für Sie wurde ein neuer Zugang ODER ein neues vorläufiges Kennwort auf \'{$a->sitename}\' angelegt. </br>
Für Sie gelten folgende Anmeldedaten: </br>
Anmeldename: {$a->username} </br>
Kennwort: {$a->newpassword} </br>
Sie werden aufgefordert, dieses Kennwort beim ersten Anmelden zu ändern. </br>
Rufen Sie {$a->sitename} auf und loggen Sie sich auf der Seite {$a->link} ein. </br>
In den meisten E-Mail-Programmen ist der Link aktiv und muss einfach angeklickt werden. Sollte das nicht funktionieren, kopieren Sie bitte die Webadresse in die Adresszeile des Browserfensters.</br>
Bei Problemen wenden Sie sich bitte an die Administrator/innen der Website. </br>
Viel Erfolg! {$a->signoff}';
